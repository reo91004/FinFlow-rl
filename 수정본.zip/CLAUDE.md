# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

BIPD (Behavioral Immune Portfolio Defense) is a biologically-inspired reinforcement learning system for portfolio management. It mimics the adaptive immune system with three specialized components:

- **T-Cell**: Crisis detection using Isolation Forest
- **B-Cell**: Specialized portfolio strategies using SAC (Soft Actor-Critic) 
- **Memory Cell**: Experience storage and retrieval for decision guidance

The system provides explainable AI (XAI) through biological metaphors, making investment decisions interpretable for financial practitioners.

## Development Commands

### Running the System
```bash
python main.py  # Complete training and evaluation pipeline
```

### Testing and Debugging
```bash
# Run individual test files in tests/ directory
python tests/test_training_debug.py          # Training signals debugging
python tests/test_environment_debug.py       # Environment functionality
python tests/test_agent_debug.py            # Agent behavior analysis
python tests/test_sac_conversion.py         # SAC algorithm validation
python tests/test_training_extended.py      # Extended training tests
python tests/analyze_algorithm_fit.py       # Algorithm fitness analysis
```

### Installing Dependencies
```bash
pip install -r requirements.txt
```

## Core Architecture

### Directory Structure
```
bipd/
├── config.py                 # Global configuration and hyperparameters
├── main.py                   # Main execution entry point
├── agents/                   # Immune system components
│   ├── tcell.py             # T-Cell: Crisis detection (Isolation Forest)
│   ├── bcell.py             # B-Cell: Strategy execution (SAC)
│   └── memory.py            # Memory Cell: Experience management
├── core/                     # Core system components
│   ├── environment.py       # Portfolio trading environment
│   ├── system.py           # Integrated immune system
│   └── trainer.py          # Training orchestrator
├── data/                     # Data processing pipeline
│   ├── loader.py           # Market data acquisition (Yahoo Finance)
│   ├── features.py         # Feature extraction (12D market characteristics)
│   └── cache/              # Cached market data
├── utils/                    # Supporting utilities
│   ├── logger.py           # Logging system
│   ├── metrics.py          # Performance calculation
│   └── visualization.py    # XAI visualization
└── tests/                    # Testing and debugging scripts
```

### Key Components

**Config System (config.py)**:
- Centralized parameter management with GPU/CPU device detection
- 43D state space (12 market features + 1 crisis level + 30 previous weights)
- 30D action space (portfolio weights for Dow Jones 30 stocks)
- SAC hyperparameters: ACTOR_LR=3e-4, CRITIC_LR=3e-4, GAMMA=0.99

**T-Cell (agents/tcell.py)**:
- Multi-dimensional crisis detection using Isolation Forest
- Outputs crisis levels for volatility, correlation, volume, and overall market stress
- Provides explainable anomaly detection with feature importance

**B-Cell (agents/bcell.py)**:
- 5 specialized SAC agents: volatility, correlation, momentum, defensive, growth
- Dirichlet distribution for portfolio weight constraints
- Prioritized Experience Replay (PER) and automatic entropy tuning

**Memory Cell (agents/memory.py)**:
- Cosine similarity-based experience retrieval
- Stores market states, actions, rewards, and crisis levels
- Provides historical guidance for similar market conditions

**Environment (core/environment.py)**:
- Realistic trading simulation with transaction costs (0.1%)
- Reward function combines portfolio returns with Sharpe ratio bonuses
- State normalization for stable learning

**Immune System (core/system.py)**:
- Orchestrates T-Cell crisis detection → B-Cell selection → portfolio generation
- Dynamic strategy selection based on crisis type and recent performance
- 20% exploration rate for strategy diversity

## Data Pipeline

**Market Data**: Dow Jones 30 stocks from Yahoo Finance
- Training: 2008-2020 (includes financial crisis)
- Testing: 2021-2024 (recent market conditions)
- Automatic caching in `data/cache/` directory

**12D Feature Extraction**:
1. Return statistics: recent return, average return, volatility
2. Technical indicators: RSI, MACD, Bollinger bands, volume ratio
3. Market structure: asset correlation, market beta, max drawdown
4. Momentum signals: short-term (5-day), long-term (20-day)

## Training Process

The system runs 500 episodes with the following phases:
1. T-Cell pre-training on normal market patterns
2. SAC training with crisis-specialized B-Cell selection
3. Memory system accumulation and experience replay
4. Performance evaluation on test data
5. Benchmark comparison against equal-weight portfolio

Output files generated in timestamped directories under `logs/`:
- Training logs: `bipd_training.log`
- Model checkpoints: `models/`
- Visualizations: `visualizations/`

## Key Configuration Parameters

Located in `config.py`:
- `N_EPISODES = 500`: Total training episodes
- `INITIAL_CAPITAL = 1000000`: Starting portfolio value
- `TRANSACTION_COST = 0.001`: Trading cost (0.1%)
- `BATCH_SIZE = 32`: SAC training batch size
- `BUFFER_SIZE = 10000`: Experience replay buffer
- `TARGET_ENTROPY_SCALE = 0.25`: Entropy regularization

## Development Notes

- The system requires significant computational resources and may take 2+ hours to complete full training
- GPU acceleration is automatically detected and used when available
- All random seeds are set for reproducibility (GLOBAL_SEED = 42)
- Extensive logging provides visibility into training progress and system decisions
- XAI explanations are generated for each portfolio decision, showing crisis detection, strategy selection, and memory influence